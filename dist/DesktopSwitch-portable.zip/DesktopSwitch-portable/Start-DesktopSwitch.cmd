@echo off
cd /d "%~dp0"
if exist "%~dp0DesktopSwitch.exe" (
  start "" "%~dp0DesktopSwitch.exe"
  exit /b 0
)
powershell.exe -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0DesktopSwitch.ps1"
