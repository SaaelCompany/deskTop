Set shell = CreateObject("Wscript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder
exePath = folder & "\DesktopSwitch.exe"
If fso.FileExists(exePath) Then
  shell.Run """" & exePath & """", 0, False
Else
  scriptPath = folder & "\DesktopSwitch.ps1"
  command = "powershell.exe -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File " & Chr(34) & scriptPath & Chr(34)
  shell.Run command, 0, False
End If
